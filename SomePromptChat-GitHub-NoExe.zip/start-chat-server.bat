@echo off
setlocal

set "APP_DIR=%~dp0"
set "PORT=3002"
set "PUBLIC_URL=https://somechatapp.ddns.net/"
set "BUNDLED_NODE=C:\Users\samul\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"

if exist "%BUNDLED_NODE%" (
  set "NODE_EXE=%BUNDLED_NODE%"
) else (
  set "NODE_EXE=node"
)

echo Starting Some Prompt Chat...
echo Address: http://127.0.0.1:%PORT%
echo Public:  %PUBLIC_URL%
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%stop-port.ps1" -Port %PORT%

> "%APP_DIR%PUBLIC-URL.txt" echo %PUBLIC_URL%
start "" "%PUBLIC_URL%"
cd /d "%APP_DIR%"
"%NODE_EXE%" server.js

pause
