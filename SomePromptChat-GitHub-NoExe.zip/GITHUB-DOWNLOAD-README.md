﻿# Some Prompt Chat - GitHub Package without EXE

This zip intentionally does NOT include `SomeChatServer.exe`, because browsers/Windows Defender may flag unknown local server executables during download.

Included:
- web chat files
- Node server
- Windows control app source code (`ChatServerControlApp.cs`)
- start/stop scripts
- empty data folder

Separate file:
- `SomeChatServer.exe` is provided beside this zip, not inside it.

To rebuild the EXE yourself on Windows:

```powershell
& 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe' /nologo /target:winexe /out:'SomeChatServer.exe' /reference:System.Windows.Forms.dll /reference:System.Drawing.dll 'ChatServerControlApp.cs'
```
