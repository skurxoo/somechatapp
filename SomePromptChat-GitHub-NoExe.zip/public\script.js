const messages = document.querySelector("#messages");
const notices = document.querySelector("#notices");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
const attachmentInput = document.querySelector("#attachmentInput");
const attachButton = document.querySelector("#attachButton");
const attachmentHint = document.querySelector("#attachmentHint");

const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;
const COMMANDS = [
  "available commands:",
  "/help     show commands",
  "/count    show how many messages are currently loaded",
  "/me       show your sender IP for this browser",
  "/time     show your local time",
  "/url      show the current chat address",
  "/refresh  reload messages"
];

let newestMessageId = "";
let currentMessages = [];

function line(message) {
  const row = document.createElement("p");
  row.className = "message";

  const time = document.createElement("span");
  time.className = "time";
  time.textContent = new Date(message.time).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });

  const text = document.createElement("span");
  text.textContent = message.text;

  row.append(time, text);

  if (message.attachment) {
    const attachment = message.attachment;
    const isImage = attachment.type && attachment.type.startsWith("image/");

    if (isImage) {
      const image = document.createElement("img");
      image.className = "message-image";
      image.src = attachment.url;
      image.alt = attachment.name || "attached image";
      image.loading = "lazy";
      row.append(image);
    }

    const link = document.createElement("a");
    link.className = "attachment-link";
    link.href = attachment.url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `file: ${attachment.name || "attachment"}`;
    row.append(link);
  }

  return row;
}

function render(list) {
  currentMessages = list;

  if (!list.length) {
    messages.replaceChildren();
    newestMessageId = "";
    return;
  }

  const last = list.at(-1);
  if (last.id === newestMessageId) return;

  messages.replaceChildren(...list.map(line));
  newestMessageId = last.id;
  messages.parentElement.scrollTop = messages.parentElement.scrollHeight;
}

async function loadMessages() {
  const response = await fetch("api/messages");
  if (!response.ok) throw new Error("Could not load messages.");
  render(await response.json());
}

function fileToAttachment(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve(null);
      return;
    }

    if (file.size > MAX_ATTACHMENT_BYTES) {
      reject(new Error("Attachment is too large. Max size is 5 MB."));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      const base64 = dataUrl.includes(",") ? dataUrl.split(",").at(-1) : dataUrl;
      resolve({
        name: file.name,
        type: file.type || "application/octet-stream",
        data: base64
      });
    };
    reader.onerror = () => reject(new Error("Could not read attachment."));
    reader.readAsDataURL(file);
  });
}

function showSystem(text, isError = false) {
  notices.replaceChildren();

  const lines = Array.isArray(text) ? text : String(text).split("\n");
  for (const line of lines) {
    const row = document.createElement("p");
    row.className = isError ? "notice error" : "notice";
    row.textContent = line;
    notices.append(row);
  }

  notices.parentElement.scrollTop = notices.parentElement.scrollHeight;
}

async function runCommand(text) {
  const [command] = text.toLowerCase().split(/\s+/);

  if (command === "/help") {
    showSystem(COMMANDS);
    return true;
  }

  if (command === "/count") {
    showSystem(`${currentMessages.length} message${currentMessages.length === 1 ? "" : "s"} loaded`);
    return true;
  }

  if (command === "/me") {
    const response = await fetch("api/me");
    if (!response.ok) {
      showSystem("could not get sender info", true);
      return true;
    }

    const me = await response.json();
    showSystem([
      `sender ip: ${me.ip || "unknown"}`,
      `browser: ${me.browser || "unknown"}`
    ]);
    return true;
  }

  if (command === "/time") {
    showSystem(new Date().toLocaleString());
    return true;
  }

  if (command === "/url") {
    showSystem(window.location.href);
    return true;
  }

  if (command === "/refresh") {
    await loadMessages();
    showSystem("messages refreshed");
    return true;
  }

  if (text.startsWith("/")) {
    showSystem(`unknown command: ${text}. type /help`, true);
    return true;
  }

  return false;
}

attachButton.addEventListener("click", () => attachmentInput.click());

attachmentInput.addEventListener("change", () => {
  const file = attachmentInput.files[0];
  attachButton.classList.toggle("has-file", Boolean(file));
  attachmentHint.textContent = file ? `attached: ${file.name}` : "";
});

form.addEventListener("submit", async event => {
  event.preventDefault();
  const text = input.value.trim();
  const file = attachmentInput.files[0];
  if (!text && !file) return;

  input.value = "";

  if (text.startsWith("/") && !file) {
    await runCommand(text);
    return;
  }

  attachmentInput.value = "";
  attachButton.classList.remove("has-file");
  attachmentHint.textContent = "";

  let attachment = null;
  try {
    attachment = await fileToAttachment(file);
  } catch (error) {
    showSystem(error.message, true);
    return;
  }

  const response = await fetch("api/messages", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text, attachment })
  });

  if (!response.ok) {
    showSystem("message failed", true);
    return;
  }

  await loadMessages();
});

loadMessages();
setInterval(loadMessages, 1500);
