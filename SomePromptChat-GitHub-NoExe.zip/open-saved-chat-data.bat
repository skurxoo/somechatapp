@echo off
start "" "%~dp0data"
