@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-public-chat.ps1"
pause
