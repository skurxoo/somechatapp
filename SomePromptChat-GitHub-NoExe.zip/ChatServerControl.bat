@echo off
start "" "%~dp0SomeChatServer.exe"
