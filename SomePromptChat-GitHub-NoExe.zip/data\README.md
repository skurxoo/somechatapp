# Permanent chat data

This folder is the permanent storage for Some Prompt Chat.

- `messages.jsonl` stores every message row-by-row.
- `uploads/` stores attached files.

Starting or stopping the server does not delete these files.
