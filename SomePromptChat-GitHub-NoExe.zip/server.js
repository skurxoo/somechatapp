const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 3002);
const HOST = process.env.HOST || "0.0.0.0";
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA = path.join(ROOT, "data");
const UPLOADS = path.join(DATA, "uploads");
const MESSAGES = path.join(DATA, "messages.jsonl");
const MAX_MESSAGE_LENGTH = 500;
const MAX_MESSAGES_RETURNED = 300;
const MAX_BODY_LENGTH = 8 * 1024 * 1024;
const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;
const COOKIE_NAME = "some_sender";

fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(MESSAGES)) fs.writeFileSync(MESSAGES, "", "utf8");

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".pdf": "application/pdf",
  ".zip": "application/zip"
};

function send(res, status, body, type = "text/plain; charset=utf-8") {
  res.writeHead(status, {
    "content-type": type,
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  res.end(body);
}

function sendJson(res, status, data, extraHeaders = {}) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    ...extraHeaders
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > MAX_BODY_LENGTH) {
        req.destroy();
        reject(new Error("Body too large"));
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function safeMessage(input) {
  return String(input || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, MAX_MESSAGE_LENGTH);
}

function parseCookies(req) {
  const header = req.headers.cookie || "";
  return Object.fromEntries(
    header
      .split(";")
      .map(cookie => cookie.trim())
      .filter(Boolean)
      .map(cookie => {
        const index = cookie.indexOf("=");
        if (index === -1) return [cookie, ""];
        return [cookie.slice(0, index), decodeURIComponent(cookie.slice(index + 1))];
      })
  );
}

function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return String(forwarded).split(",")[0].trim();
  return req.socket.remoteAddress || "";
}

function getSender(req) {
  const cookies = parseCookies(req);
  const existing = cookies[COOKIE_NAME];
  const isValid = existing && /^some-[a-f0-9]{8}$/.test(existing);
  const id = isValid ? existing : `some-${crypto.randomBytes(4).toString("hex")}`;
  const ip = getClientIp(req);
  const userAgent = String(req.headers["user-agent"] || "").slice(0, 240);

  return {
    id,
    isNew: !isValid,
    public: {
      id,
      ip,
      browser: userAgent,
      firstSeen: new Date().toISOString()
    }
  };
}

function senderCookie(sender) {
  return `${COOKIE_NAME}=${encodeURIComponent(sender.id)}; Path=/; SameSite=Lax; Max-Age=31536000`;
}

function safeFilename(input) {
  const cleaned = String(input || "attachment")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, "_")
    .slice(0, 80);

  return cleaned || "attachment";
}

function saveAttachment(input) {
  if (!input || !input.data) return null;

  const base64 = String(input.data);
  const buffer = Buffer.from(base64, "base64");

  if (!buffer.length) return null;
  if (buffer.length > MAX_ATTACHMENT_BYTES) {
    const error = new Error("Attachment is too large.");
    error.status = 413;
    throw error;
  }

  const originalName = safeFilename(input.name);
  const ext = path.extname(originalName).slice(0, 16);
  const storedName = `${Date.now()}-${crypto.randomUUID()}${ext}`;
  const diskPath = path.join(UPLOADS, storedName);

  fs.writeFileSync(diskPath, buffer);

  return {
    name: originalName,
    type: String(input.type || "application/octet-stream").slice(0, 100),
    size: buffer.length,
    url: `uploads/${storedName}`
  };
}

function getMessages() {
  const rows = fs.readFileSync(MESSAGES, "utf8")
    .split(/\r?\n/)
    .filter(Boolean)
    .slice(-MAX_MESSAGES_RETURNED);

  return rows.flatMap(row => {
    try {
      return [JSON.parse(row)];
    } catch {
      return [];
    }
  });
}

function clearMessages() {
  fs.writeFileSync(MESSAGES, "", "utf8");

  for (const entry of fs.readdirSync(UPLOADS, { withFileTypes: true })) {
    if (!entry.isFile()) continue;
    fs.rmSync(path.join(UPLOADS, entry.name), { force: true });
  }
}

function uploadedFile(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const requested = decodeURIComponent(url.pathname.replace(/^\/uploads\//, ""));
  const filePath = path.normalize(path.join(UPLOADS, requested));

  if (!filePath.startsWith(UPLOADS)) {
    send(res, 403, "Forbidden");
    return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      send(res, 404, "Not found");
      return;
    }

    send(res, 200, content, contentTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream");
  });
}

function staticFile(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const requested = url.pathname === "/" ? "/index.html" : url.pathname;
  const filePath = path.normalize(path.join(PUBLIC, requested));

  if (!filePath.startsWith(PUBLIC)) {
    send(res, 403, "Forbidden");
    return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      send(res, 404, "Not found");
      return;
    }

    send(res, 200, content, contentTypes[path.extname(filePath)] || "application/octet-stream");
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "GET" && url.pathname === "/api/messages") {
      send(res, 200, JSON.stringify(getMessages()), "application/json; charset=utf-8");
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/me") {
      const sender = getSender(req);
      sendJson(res, 200, sender.public, sender.isNew ? { "set-cookie": senderCookie(sender) } : {});
      return;
    }

    if (req.method === "DELETE" && url.pathname === "/api/messages") {
      const token = req.headers["x-control-token"];
      const expected = process.env.CONTROL_TOKEN || "";
      if (!expected || token !== expected) {
        send(res, 403, JSON.stringify({ error: "Clear is only available from the server app." }), "application/json; charset=utf-8");
        return;
      }

      clearMessages();
      send(res, 200, JSON.stringify({ ok: true }), "application/json; charset=utf-8");
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/messages") {
      const body = JSON.parse(await readBody(req));
      const text = safeMessage(body.text);
      const attachment = saveAttachment(body.attachment);
      const sender = getSender(req);

      if (!text && !attachment) {
        send(res, 400, JSON.stringify({ error: "Message or attachment is required." }), "application/json; charset=utf-8");
        return;
      }

      const message = {
        id: crypto.randomUUID(),
        text,
        time: new Date().toISOString(),
        sender: sender.public,
        attachment
      };

      fs.appendFileSync(MESSAGES, JSON.stringify(message) + "\n", "utf8");
      sendJson(res, 201, message, sender.isNew ? { "set-cookie": senderCookie(sender) } : {});
      return;
    }

    if (req.method === "GET") {
      if (url.pathname.startsWith("/uploads/")) {
        uploadedFile(req, res);
        return;
      }

      staticFile(req, res);
      return;
    }

    send(res, 405, "Method not allowed");
  } catch (error) {
    send(res, error.status || 500, JSON.stringify({ error: error.message || "Server error." }), "application/json; charset=utf-8");
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Some Prompt Chat is running at http://127.0.0.1:${PORT}`);
});
