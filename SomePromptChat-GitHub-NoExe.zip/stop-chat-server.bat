@echo off
setlocal

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop-port.ps1" -Port 3002
echo Some Prompt Chat server stopped.
pause
