$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$CaddyPid = Join-Path $AppDir "caddy-public.pid"
$ChatPid = Join-Path $AppDir "chat-public.pid"

function Stop-PidFile {
  param(
    [string]$Path,
    [string]$Name
  )

  if (-not (Test-Path -LiteralPath $Path)) { return }

  try {
    $processId = [int](Get-Content -LiteralPath $Path -Raw)
    Stop-Process -Id $processId -Force -ErrorAction Stop
    Write-Host "Stopped $Name PID $processId."
  } catch {}

  Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
}

function Stop-ListenersByName {
  param(
    [int]$Port,
    [string]$ProcessName
  )

  $lines = netstat -ano | Select-String ":$Port"
  foreach ($line in $lines) {
    $parts = ($line.ToString() -split "\s+") | Where-Object { $_ }
    if ($parts.Count -lt 5) { continue }
    if ($parts[1] -notmatch ":$Port$") { continue }
    if ($parts[3] -ne "LISTENING") { continue }

    $processId = [int]$parts[-1]
    try {
      $process = Get-Process -Id $processId -ErrorAction Stop
      if ($process.ProcessName -eq $ProcessName) {
        Stop-Process -Id $process.Id -Force
        Write-Host "Stopped $ProcessName on port $Port (PID $($process.Id))."
      }
    } catch {}
  }
}

Stop-PidFile -Path $ChatPid -Name "chat server"
Stop-PidFile -Path $CaddyPid -Name "Caddy"
& (Join-Path $AppDir "stop-port.ps1") -Port 3002
Stop-ListenersByName -Port 443 -ProcessName "caddy"
Stop-ListenersByName -Port 2019 -ProcessName "caddy"
Write-Host "Public some chat stopped."
