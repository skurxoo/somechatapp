# Some Prompt Chat

A very small some web chat that feels like a command prompt.

- No accounts
- No names
- One plain text input
- Messages are permanently saved row by row in `data/messages.jsonl`
- Attachments are permanently saved in `data/uploads/`
- No npm dependencies

## Chat commands

Type these into the chat input:

```text
/help
/count
/me
/time
/url
/refresh
```

Clearing saved messages is only available from the Windows server control app.
New messages also store sender info in `data/messages.jsonl`: sender ID, IP address, browser user-agent, and message time. The chat page does not show sender info.

## Run locally

On this Windows computer, double-click:

```text
start-chat-server.bat
```

Then open:

```text
http://127.0.0.1:3002
```

If the No-IP HTTPS gateway is running, public access is:

```text
https://somechatapp.ddns.net/
```

To start the public No-IP version in one click, double-click:

```text
start-public-chat.bat
```

It starts Caddy and the chat server in the background, writes logs beside the launcher, and opens:

```text
https://somechatapp.ddns.net/
```

To stop the public No-IP version, double-click:

```text
stop-public-chat.bat
```

For a real small Windows control program with Start and Stop buttons, double-click:

```text
SomeChatServer.exe
```

To open the saved chat folder directly, double-click:

```text
open-saved-chat-data.bat
```

To stop it, close the server window or double-click:

```text
stop-chat-server.bat
```

## Run manually

```bash
npm start
```

Then open:

```text
http://127.0.0.1:3002
```

## Change the port

```bash
PORT=8080 npm start
```

On Windows PowerShell:

```powershell
$env:PORT=8080; npm start
```

## Important

This is intentionally some, but it is not moderated and does not include login, admin tools, spam protection, or encryption by itself. Put it behind HTTPS if you publish it on the internet.
