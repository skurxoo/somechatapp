﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SomePromptChat
{
    public class ControlApp : Form
    {
        private readonly string appDir;
        private readonly string publicUrl = "https://somechatapp.ddns.net/";
        private readonly string localUrl = "http://127.0.0.1:3002/";
        private readonly string caddyExe = @"C:\Users\samul\Documents\GitHub\ChatApp\caddy.exe";
        private readonly string caddyFile = @"C:\Users\samul\Documents\GitHub\ChatApp\Caddyfile";
        private readonly string nodeExe = @"C:\Users\samul\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe";
        private readonly string controlToken = "some-control-local-only";

        private readonly Label statusLabel = new Label();
        private readonly Label detailsLabel = new Label();
        private readonly Timer timer = new Timer();

        private string MessagesFile { get { return Path.Combine(appDir, "data", "messages.jsonl"); } }
        private string UploadsDir { get { return Path.Combine(appDir, "data", "uploads"); } }
        private string ServerJs { get { return Path.Combine(appDir, "server.js"); } }
        private string PublicUrlFile { get { return Path.Combine(appDir, "PUBLIC-URL.txt"); } }
        private string CaddyLog { get { return Path.Combine(appDir, "caddy-public.log"); } }
        private string ChatLog { get { return Path.Combine(appDir, "chat-public.log"); } }
        private string CaddyPid { get { return Path.Combine(appDir, "caddy-public.pid"); } }
        private string ChatPid { get { return Path.Combine(appDir, "chat-public.pid"); } }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ControlApp());
        }

        public ControlApp()
        {
            appDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            EnsureStorage();
            BuildUi();

            timer.Interval = 2500;
            timer.Tick += delegate { RefreshStatus(); };
            timer.Start();
            RefreshStatus();
        }

        private void BuildUi()
        {
            Text = "Some Chat Server";
            Size = new Size(440, 445);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.FromArgb(5, 12, 5);
            ForeColor = Color.FromArgb(124, 255, 139);
            Font = new Font("Consolas", 10);

            var title = new Label();
            title.Text = "some prompt chat";
            title.Location = new Point(18, 18);
            title.Size = new Size(390, 30);
            title.Font = new Font("Consolas", 14, FontStyle.Bold);
            Controls.Add(title);

            statusLabel.Location = new Point(20, 55);
            statusLabel.Size = new Size(390, 26);
            Controls.Add(statusLabel);

            detailsLabel.Location = new Point(20, 82);
            detailsLabel.Size = new Size(390, 58);
            detailsLabel.ForeColor = Color.FromArgb(79, 168, 90);
            Controls.Add(detailsLabel);

            var start = MakeButton("Start", 20, 150);
            var stop = MakeButton("Stop", 150, 150);
            var open = MakeButton("Open chat", 280, 150);
            var folder = MakeButton("Saved folder", 20, 200);
            var file = MakeButton("Messages file", 150, 200);
            var project = MakeButton("Project folder", 280, 200);
            var clear = MakeButton("Clear messages", 20, 250, 150);

            start.Click += delegate { StartServer(); RefreshSoon(); };
            stop.Click += delegate { StopServer(); RefreshSoon(); };
            open.Click += delegate { Open(publicUrl); };
            folder.Click += delegate { Open(Path.Combine(appDir, "data")); };
            file.Click += delegate { Open(MessagesFile); };
            project.Click += delegate { Open(appDir); };
            clear.Click += delegate { ClearMessagesFromApp(); RefreshSoon(); };

            Controls.Add(start);
            Controls.Add(stop);
            Controls.Add(open);
            Controls.Add(folder);
            Controls.Add(file);
            Controls.Add(project);
            Controls.Add(clear);

            var note = new TextBox();
            note.Location = new Point(20, 305);
            note.Size = new Size(390, 75);
            note.Multiline = true;
            note.ReadOnly = true;
            note.BorderStyle = BorderStyle.FixedSingle;
            note.BackColor = Color.FromArgb(7, 24, 7);
            note.ForeColor = Color.FromArgb(79, 168, 90);
            note.Text = "Close this window if you want." + Environment.NewLine +
                        "The server keeps running in the background." + Environment.NewLine +
                        "Open this app again to check, stop, or clear it.";
            Controls.Add(note);
        }

        private Button MakeButton(string text, int x, int y, int width = 118)
        {
            var button = new Button();
            button.Text = text;
            button.Location = new Point(x, y);
            button.Size = new Size(width, 36);
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = Color.FromArgb(7, 24, 7);
            button.ForeColor = Color.FromArgb(124, 255, 139);
            return button;
        }

        private void EnsureStorage()
        {
            Directory.CreateDirectory(Path.Combine(appDir, "data"));
            Directory.CreateDirectory(UploadsDir);
            if (!File.Exists(MessagesFile))
                File.WriteAllText(MessagesFile, "");
            File.WriteAllText(PublicUrlFile, publicUrl);
        }

        private void StartServer()
        {
            EnsureStorage();
            StopServer();

            if (!File.Exists(caddyExe))
            {
                MessageBox.Show("Missing Caddy:\n" + caddyExe, "Cannot start", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!File.Exists(caddyFile))
            {
                MessageBox.Show("Missing Caddyfile:\n" + caddyFile, "Cannot start", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!File.Exists(nodeExe))
            {
                MessageBox.Show("Missing Node runtime:\n" + nodeExe, "Cannot start", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            StartLoggedProcess(caddyExe, "run --config " + Quote(caddyFile), CaddyLog, CaddyPid);
            StartLoggedProcess(nodeExe, Quote(ServerJs), ChatLog, ChatPid, controlToken);
            Open(publicUrl);
        }

        private void StopServer()
        {
            StopPidFile(ChatPid);
            StopPidFile(CaddyPid);
            StopListenersOnPort(3002);
            StopListenersOnPort(443);
            StopListenersOnPort(2019);
        }

        private void ClearMessagesFromApp()
        {
            var confirm = MessageBox.Show(
                "Remove all saved messages and attachments?",
                "Clear Some Prompt Chat",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            try
            {
                using (var client = new System.Net.WebClient())
                {
                    client.Headers.Add("X-Control-Token", controlToken);
                    client.UploadString(localUrl + "api/messages", "DELETE", "");
                }
            }
            catch
            {
                try
                {
                    File.WriteAllText(MessagesFile, "");
                    foreach (var file in Directory.GetFiles(UploadsDir))
                        File.Delete(file);
                }
                catch { }
            }

            MessageBox.Show("Messages and attachments cleared.", "Clear complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void StartLoggedProcess(string exe, string arguments, string logPath, string pidPath, string token = null)
        {
            var info = new ProcessStartInfo(exe, arguments);
            info.WorkingDirectory = appDir;
            info.CreateNoWindow = true;
            info.UseShellExecute = false;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            if (!string.IsNullOrEmpty(token))
                info.EnvironmentVariables["CONTROL_TOKEN"] = token;
            var process = Process.Start(info);
            if (process == null) return;

            File.WriteAllText(pidPath, process.Id.ToString());
            process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
            {
                if (e.Data != null) AppendLog(logPath, e.Data);
            };
            process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
            {
                if (e.Data != null) AppendLog(logPath, e.Data);
            };
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
        }

        private void AppendLog(string path, string line)
        {
            try
            {
                File.AppendAllText(path, line + Environment.NewLine);
            }
            catch { }
        }

        private void StopPidFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return;
                int pid;
                if (int.TryParse(File.ReadAllText(path).Trim(), out pid))
                {
                    var process = Process.GetProcessById(pid);
                    process.Kill();
                }
                File.Delete(path);
            }
            catch
            {
                try { File.Delete(path); } catch { }
            }
        }

        private void StopListenersOnPort(int port)
        {
            foreach (var pid in ListenerPids(port))
            {
                try
                {
                    var process = Process.GetProcessById(pid);
                    var name = process.ProcessName.ToLowerInvariant();
                    if (name == "node" || name == "caddy")
                        process.Kill();
                }
                catch { }
            }
        }

        private int[] ListenerPids(int port)
        {
            try
            {
                var info = new ProcessStartInfo("netstat.exe", "-ano -p tcp");
                info.CreateNoWindow = true;
                info.UseShellExecute = false;
                info.RedirectStandardOutput = true;
                var process = Process.Start(info);
                var output = process.StandardOutput.ReadToEnd();
                process.WaitForExit(3000);

                var pids = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(line => Regex.Split(line.Trim(), @"\s+"))
                    .Where(parts => parts.Length >= 5)
                    .Where(parts => parts[1].EndsWith(":" + port))
                    .Where(parts => parts[3].Equals("LISTENING", StringComparison.OrdinalIgnoreCase))
                    .Select(parts =>
                    {
                        int pid;
                        return int.TryParse(parts[4], out pid) ? pid : -1;
                    })
                    .Where(pid => pid > 0)
                    .Distinct()
                    .ToArray();
                return pids;
            }
            catch
            {
                return new int[0];
            }
        }

        private bool IsPortListening(int port)
        {
            return ListenerPids(port).Length > 0;
        }

        private int CountMessages()
        {
            try
            {
                if (!File.Exists(MessagesFile)) return 0;
                return File.ReadLines(MessagesFile).Count(line => line.Trim().Length > 0);
            }
            catch
            {
                return 0;
            }
        }

        private void RefreshSoon()
        {
            var refresh = new Timer();
            refresh.Interval = 1200;
            refresh.Tick += delegate
            {
                refresh.Stop();
                refresh.Dispose();
                RefreshStatus();
            };
            refresh.Start();
        }

        private void RefreshStatus()
        {
            var chat = IsPortListening(3002);
            var https = IsPortListening(443);
            string state;
            if (chat && https) state = "Running";
            else if (chat) state = "Chat running, HTTPS off";
            else if (https) state = "HTTPS running, chat off";
            else state = "Stopped";

            statusLabel.Text = "Status: " + state;
            statusLabel.ForeColor = state == "Running"
                ? Color.FromArgb(124, 255, 139)
                : Color.FromArgb(255, 200, 90);
            detailsLabel.Text = "Public: " + publicUrl + Environment.NewLine +
                                "Local:  " + localUrl + Environment.NewLine +
                                "Saved messages: " + CountMessages();
        }

        private void Open(string target)
        {
            try
            {
                var info = new ProcessStartInfo(target);
                info.UseShellExecute = true;
                Process.Start(info);
            }
            catch { }
        }

        private static string Quote(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }
    }
}

