param(
  [int]$Port = 3002
)

$connections = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue

foreach ($connection in $connections) {
  $processId = $connection.OwningProcess
  if ($processId -and $processId -ne $PID) {
    try {
      Stop-Process -Id $processId -Force -ErrorAction Stop
      Write-Host "Stopped stale process on port $Port (PID $processId)."
    } catch {
      Write-Host "Could not stop process on port $Port (PID $processId): $($_.Exception.Message)"
    }
  }
}
