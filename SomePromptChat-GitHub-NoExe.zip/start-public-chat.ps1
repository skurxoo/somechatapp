$ErrorActionPreference = "Stop"

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PublicUrl = "https://somechatapp.ddns.net/"
$Port = 3002
$CaddyExe = "C:\Users\samul\Documents\GitHub\ChatApp\caddy.exe"
$Caddyfile = "C:\Users\samul\Documents\GitHub\ChatApp\Caddyfile"
$NodeExe = "C:\Users\samul\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
$ServerJs = Join-Path $AppDir "server.js"
$PublicUrlFile = Join-Path $AppDir "PUBLIC-URL.txt"
$CaddyOut = Join-Path $AppDir "caddy-public.out.log"
$CaddyErr = Join-Path $AppDir "caddy-public.err.log"
$ChatOut = Join-Path $AppDir "chat-public.out.log"
$ChatErr = Join-Path $AppDir "chat-public.err.log"
$CaddyPid = Join-Path $AppDir "caddy-public.pid"
$ChatPid = Join-Path $AppDir "chat-public.pid"
$ControlToken = "some-control-local-only"

if (-not (Test-Path -LiteralPath $CaddyExe)) {
  throw "Missing Caddy: $CaddyExe"
}

if (-not (Test-Path -LiteralPath $Caddyfile)) {
  throw "Missing Caddyfile: $Caddyfile"
}

if (-not (Test-Path -LiteralPath $NodeExe)) {
  $NodeExe = "node"
}

Set-Content -LiteralPath $PublicUrlFile -Value $PublicUrl -Encoding ascii

function Stop-ListenersByName {
  param(
    [int]$Port,
    [string]$ProcessName
  )

  $lines = netstat -ano | Select-String ":$Port"
  foreach ($line in $lines) {
    $parts = ($line.ToString() -split "\s+") | Where-Object { $_ }
    if ($parts.Count -lt 5) { continue }
    if ($parts[1] -notmatch ":$Port$") { continue }
    if ($parts[3] -ne "LISTENING") { continue }

    $processId = [int]$parts[-1]
    try {
      $process = Get-Process -Id $processId -ErrorAction Stop
      if ($process.ProcessName -eq $ProcessName) {
        Stop-Process -Id $process.Id -Force
        Write-Host "Stopped stale $ProcessName on port $Port (PID $($process.Id))."
      }
    } catch {}
  }
}

Write-Host "Preparing public chat at $PublicUrl"
Stop-ListenersByName -Port 2019 -ProcessName "caddy"
Stop-ListenersByName -Port 443 -ProcessName "caddy"

& (Join-Path $AppDir "stop-port.ps1") -Port $Port

Remove-Item -LiteralPath $CaddyOut, $CaddyErr, $ChatOut, $ChatErr -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $CaddyPid, $ChatPid -ErrorAction SilentlyContinue

Write-Host "Starting Caddy HTTPS gateway..."
$caddyProcess = Start-Process -FilePath $CaddyExe `
  -ArgumentList @("run", "--config", $Caddyfile) `
  -RedirectStandardOutput $CaddyOut `
  -RedirectStandardError $CaddyErr `
  -PassThru
Set-Content -LiteralPath $CaddyPid -Value $caddyProcess.Id -Encoding ascii

Write-Host "Starting some chat server..."
$env:CONTROL_TOKEN = $ControlToken
$chatProcess = Start-Process -FilePath $NodeExe `
  -ArgumentList @("`"$ServerJs`"") `
  -RedirectStandardOutput $ChatOut `
  -RedirectStandardError $ChatErr `
  -PassThru
Remove-Item Env:\CONTROL_TOKEN -ErrorAction SilentlyContinue
Set-Content -LiteralPath $ChatPid -Value $chatProcess.Id -Encoding ascii

Start-Sleep -Seconds 3

if ($caddyProcess.HasExited) {
  Write-Host "Caddy exited early. Error log:"
  Get-Content -LiteralPath $CaddyErr -ErrorAction SilentlyContinue
  throw "Caddy did not stay running."
}

if ($chatProcess.HasExited) {
  Write-Host "Chat server exited early. Error log:"
  Get-Content -LiteralPath $ChatErr -ErrorAction SilentlyContinue
  throw "Chat server did not stay running."
}

Write-Host "Public chat is starting at $PublicUrl"
Start-Process $PublicUrl
