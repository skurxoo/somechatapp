﻿# Some Prompt Chat - Clean GitHub Package

This package is stripped for GitHub/download use.

It does not include saved chat messages, uploaded files, logs, PID/runtime files, or .git folders.

Run:
1. Open `SomeChatServer.exe`.
2. Press `Start`.
3. Open `http://127.0.0.1:3002/` locally or your configured No-IP URL.
